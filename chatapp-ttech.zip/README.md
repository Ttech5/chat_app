# chat_app
A fastapi and react chat app
