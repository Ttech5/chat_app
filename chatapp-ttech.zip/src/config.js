export const url = "https://chatapp-backend1.up.railway.app";
export const websocker_url = "ws://chatapp-backend1.up.railway.app";
